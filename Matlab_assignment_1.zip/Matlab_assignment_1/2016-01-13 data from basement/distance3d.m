%% 30571 - Smart city sensor
% Find distance in 3d and calibrate
% Peter Savnik
%%%%%%%%%%%%%%%%%%%%%%

% sensor position [x,y,z] in meters
pi1 = [0,0,0];
pi2 = [20,0,0];
pi3 = [40,0,0];
pi4 = [50,0,0];


% import data

% for each measuring calculate position
for i = 1:length of data
    
end