%% 30571 - Smart city sensor
% Data calibration from logfiles of Mac_logger.py
% Peter Savnik
%%%%%%%%%%%%%%%%%%%%%%
clear all;
close all;



